<?php

namespace Tests\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TestsPlatformBundle extends Bundle
{
}
